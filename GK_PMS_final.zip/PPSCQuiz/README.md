# G-K PMS (Kotlin + Jetpack Compose)

Offline MCQ practice app for PPSC / Punjab PMS preparation.
Tick an option (checkbox): it turns green if right or red if wrong, the correct answer is shown, with an explanation.

## Features
- Categories (built-in papers + your own) with question counts
- Search across all categories (question text and options); tap a result to open that question
- NEW / نیا labels for newly added questions and categories (shown until the category is opened)
- Tick the checkbox to check the answer (first tick is final) and read the explanation
- Option order (A, B, C, D) shuffled every attempt - switch on/off on the first screen
- "None of these" / "All of the above" options keep their position when shuffling
- Result screen: score, percentage, correct/wrong counts, review of mistakes
- Upload MCQs from photos, PDFs and Word (.docx) files: questions, A-D options and answers are found automatically, grouped into categories (new categories are created when missing), checked in a preview screen, then saved with a NEW label
- Uploaded MCQs: options are shuffled automatically when saved, explanation is taken from the file, or fetched online from Wikipedia when missing (saved for offline use), duplicates are skipped, and categories are listed under their section
- Online translation: tap the **اردو** button on the question screen to show Urdu under the question and each option (needs internet; everything else works offline)
- Questions load from `app/src/main/assets/questions.json`

## Adding questions
Edit `app/src/main/assets/questions.json`. To add a paper, add a new object inside `"papers"`.
Each question:
```json
{ "number": 1, "text": "...", "options": ["A text", "B text", "C text", "D text"], "answer": 2 }
```
`answer` is the 0-based index of the correct option (0 = A, 1 = B, 2 = C, 3 = D).
Each paper needs a unique `"id"`.

## Getting the APK
The **Build G-K PMS APK** workflow builds `G-K-PMS.apk` on every push, and publishes it under **Releases**.
- Upload this project as a **.zip** to the repository (do not extract it): the workflow unzips and builds it automatically.
- Or push the extracted files with git. Both work.
- You can also start a build from the Actions tab ("Run workflow").

See `GITHUB_GUIDE.md` (Roman Urdu) for step-by-step instructions. The workflow file is `.github/workflows/build-apk.yml`.

## Project structure
```
app/src/main/
  assets/questions.json        questions data
  java/com/ppsc/quiz/
    Models.kt                  Paper, Question, ShownQuestion, MissedQuestion, shuffle
    QuestionRepository.kt      reads questions.json and merges user categories
    UserStore.kt               user-added questions saved on the phone (survives app updates)
    Search.kt                  search across categories
    QuizViewModel.kt           quiz + translation state
    McqParser.kt               finds questions/options/answers in text
    Categorizer.kt             keyword-based category guess
    ImportEngine.kt            reads .docx, PDF (OCR) and photos (OCR)
    Translator.kt              online English -> Urdu (Google endpoint, MyMemory fallback)
    MainActivity.kt            navigation between screens
    ui/                        Theme, HomeScreen, QuizScreen, ResultScreen, ImportScreen
.github/workflows/build-apk.yml   APK build (unzips an uploaded zip if needed)
app/src/main/res/                  app name "G-K PMS", launcher icon (adaptive + PNG)
```

## Translation notes
- Uses the public Google Translate endpoint (no key, unofficial, can change) and falls back to MyMemory (free daily limit).
- Question text is sent to those services only while the اردو button is on.
- To change the language edit `TARGET_LANG` in `Translator.kt` (`ur` Urdu, `pa` Punjabi, `hi` Hindi).

## Upload notes
- **Word (.docx):** text is read directly - the most accurate source.
- **Photos and PDFs:** read with on-device OCR (Google ML Kit, English/Latin text only; Urdu text is not read). PDF pages are rendered and OCR'd, so scanned and normal PDFs both work. Always check the preview: OCR can misread words.
- **Answers** must be written in the file ("Answer: C", "Correct Answer: A. ...", "Ans: b", or an answer key like "1. B 2. C"). A green highlight alone cannot be read; questions without an answer get A/B/C/D buttons in the preview.
- **Categories:** headings in the file ("A1. Pakistan: Economy", "Topic: Physics") are used first; otherwise keywords decide (Current Affairs, Physical Sciences, Biological Sciences, Environmental Studies, Food Sciences, Computer Science & IT, Basic Mathematics, General Knowledge, English, Urdu, Islamic Studies). You can change any category in the preview, or set one category for all.
- Duplicate questions (same text in the same category) are skipped.
- Saved questions live in the app's private storage and survive updates; they are not shared between phones.
