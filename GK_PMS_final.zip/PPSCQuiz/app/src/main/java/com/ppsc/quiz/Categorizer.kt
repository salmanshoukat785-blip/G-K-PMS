package com.ppsc.quiz

/**
 * Guesses a category for a question that has no heading, by counting keywords.
 * Returns the best match, or null when nothing matches. Names match the section names
 * from the syllabus (01_General_Knowledge.docx), so they merge into the same categories.
 */
object Categorizer {

    const val FALLBACK = "General Knowledge"

    private class Rule(val name: String, words: List<String>) {
        val patterns = words.map {
            Regex("""\b""" + Regex.escape(it) + """\b""", RegexOption.IGNORE_CASE)
        }
    }

    // Order matters: on a tie the earlier (more specific) category wins.
    private val rules = listOf(
        Rule("Islamic Studies (general knowledge area)", listOf("quran", "holy prophet", "prophet", "hadith", "sunnah", "islam",
            "islamic", "namaz", "salah", "zakat", "hajj", "ramadan", "caliph", "khalifa", "sahaba",
            "makkah", "mecca", "madina", "medina", "surah", "ayah", "fiqh", "imam", "seerat", "hijrah",
            "khilafat", "rashidun", "pbuh", "bukhari")),
        Rule("English", listOf("synonym", "antonym", "grammar", "tense", "passive voice", "active voice",
            "preposition", "idiom", "proverb", "adjective", "adverb", "noun", "pronoun", "verb",
            "conjunction", "punctuation", "spelling", "fill in the blank", "one word", "meaning of")),
        Rule("Computer Science and Information Technology", listOf("computer", "software", "hardware", "cpu", "ram", "rom",
            "operating system", "internet", "network", "protocol", "ip address", "database", "algorithm",
            "programming", "python", "html", "ms word", "excel", "powerpoint", "windows", "binary",
            "byte", "keyboard", "browser", "cyber", "malware", "phishing", "firewall", "encryption",
            "cloud", "artificial intelligence", "blockchain", "wifi", "email", "url")),
        Rule("Basic Mathematics", listOf("calculate", "sum", "product", "ratio", "percent", "percentage",
            "fraction", "decimal", "equation", "algebra", "triangle", "circle", "area", "perimeter",
            "volume", "angle", "square root", "matrix", "sequence", "series", "probability", "median",
            "average", "simplify", "solve", "hypotenuse", "geometry", "interest")),
        Rule("Food Sciences", listOf("nutrition", "nutrient", "calorie", "carbohydrate", "food", "mineral",
            "preservation", "pasteurization", "adulteration", "fermentation", "spoilage", "diet",
            "malnutrition", "dairy", "fortification", "packaging", "shelf life", "haccp")),
        Rule("Environmental Studies", listOf("climate", "global warming", "greenhouse", "ozone", "pollution",
            "ecosystem", "biodiversity", "carbon", "emission", "deforestation", "environment",
            "sustainable", "renewable", "recycling", "wetland", "forest", "paris agreement", "kyoto",
            "habitat", "conservation", "acid rain", "erosion", "fossil fuel", "water cycle")),
        Rule("Biological Sciences", listOf("cell", "dna", "rna", "gene", "protein", "enzyme", "chromosome",
            "photosynthesis", "mitochondria", "bacteria", "virus", "vitamin", "blood", "heart", "kidney",
            "liver", "hormone", "organism", "species", "evolution", "plant", "animal", "tissue",
            "respiration", "digestive", "nervous", "disease", "antibody", "vaccine")),
        Rule("Physical Sciences", listOf("physics", "chemistry", "atom", "atomic", "electron", "proton",
            "neutron", "molecule", "element", "acid", "gravity", "velocity", "acceleration", "force",
            "energy", "wave", "magnet", "magnetic", "voltage", "resistance", "planet", "solar system",
            "galaxy", "earthquake", "volcano", "periodic table", "nuclear", "radioactive", "isotope",
            "newton", "joule", "watt")),
        Rule("Current Affairs", listOf("2021", "2022", "2023", "2024", "2025", "2026", "summit",
            "prime minister", "budget", "imf", "united nations", "election", "elections", "world cup",
            "olympics", "olympic", "sanctions", "treaty", "oic", "nato", "saarc", "brics", "g20", "g7",
            "cpec", "senate", "parliament", "inflation", "ceasefire", "world happiness", "world bank")),
        Rule("General Knowledge", listOf("invented", "inventor", "discovered", "discovery", "founded",
            "founder", "capital of", "currency", "river", "largest", "longest", "highest", "smallest",
            "battle", "empire", "chief justice", "independence", "national", "constitution", "governor",
            "dynasty", "fell", "conquered", "born", "died", "author", "wrote", "novel", "nobel"))
    )

    private val urduIslamic = listOf("قرآن", "قران", "حدیث", "نماز", "روزہ", "زکوٰۃ", "حج", "نبی", "رسول", "صحابہ", "اسلام")

    fun classify(text: String, options: List<String>): String? {
        val all = text + " " + options.joinToString(" ")

        // Urdu-script question: Urdu, or Islamic Studies when it talks about Islam
        val letters = all.count { it.isLetter() }
        if (letters > 0) {
            val arabic = all.count { it in '\u0600'..'\u06FF' }
            if (arabic * 100 / letters >= 30) {
                return if (urduIslamic.any { all.contains(it) }) "Islamic Studies (general knowledge area)" else "Urdu"
            }
        }

        var best: String? = null
        var bestScore = 0
        for (rule in rules) {
            val score = rule.patterns.count { it.containsMatchIn(all) }
            if (score > bestScore) {
                best = rule.name
                bestScore = score
            }
        }
        return best
    }
}
