package com.ppsc.quiz

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Xml
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.IOException
import java.io.InputStream
import java.util.UUID
import java.util.zip.ZipInputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.xmlpull.v1.XmlPullParser

/** A question in the preview list, before it is saved. */
data class DraftQuestion(
    val id: String = UUID.randomUUID().toString(),
    val include: Boolean = true,
    val text: String,
    val options: List<String>,   // 4 entries
    val answer: Int?,            // null = not found in the file, user must choose
    val category: String,
    val source: String,
    val explanation: String = ""
) {
    val isValid: Boolean
        get() = text.isNotBlank() && options.size == 4 && options.all { it.isNotBlank() } &&
            answer != null && answer in 0..3
}

/** Reads the text out of .docx, PDF and photo files. */
object ImportEngine {

    private val recognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    fun displayName(context: Context, uri: Uri): String {
        try {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { c ->
                    if (c.moveToFirst()) {
                        val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (i >= 0) return c.getString(i)
                    }
                }
        } catch (e: Exception) {
            // fall through
        }
        return uri.lastPathSegment ?: "file"
    }

    suspend fun extractText(context: Context, uri: Uri, onProgress: (String) -> Unit): String {
        val name = displayName(context, uri).lowercase()
        val mime = context.contentResolver.getType(uri) ?: ""
        return when {
            name.endsWith(".docx") || mime.contains("wordprocessingml") -> {
                onProgress("reading Word file")
                withContext(Dispatchers.IO) {
                    context.contentResolver.openInputStream(uri)?.use { DocxReader.read(it) }
                        ?: throw IOException("Cannot open file")
                }
            }
            name.endsWith(".pdf") || mime == "application/pdf" -> pdfText(context, uri, onProgress)
            mime.startsWith("image/") || Regex(""".*\.(jpg|jpeg|png|webp|heic|bmp)$""").matches(name) -> {
                onProgress("reading text from photo")
                val image = withContext(Dispatchers.IO) { InputImage.fromFilePath(context, uri) }
                recognizer.process(image).await().text
            }
            name.endsWith(".doc") -> throw IOException("Old .doc format is not supported - save it as .docx")
            else -> throw IOException("Unsupported file type")
        }
    }

    /** PDF pages are drawn to pictures and read with OCR (works for scanned and normal PDFs). */
    private suspend fun pdfText(context: Context, uri: Uri, onProgress: (String) -> Unit): String {
        val pfd = withContext(Dispatchers.IO) { context.contentResolver.openFileDescriptor(uri, "r") }
            ?: throw IOException("Cannot open PDF")
        val sb = StringBuilder()
        try {
            val renderer = PdfRenderer(pfd)
            try {
                val pages = renderer.pageCount
                for (i in 0 until pages) {
                    onProgress("page ${i + 1} of $pages")
                    val bitmap = withContext(Dispatchers.IO) {
                        val page = renderer.openPage(i)
                        try {
                            val scale = minOf(2.5f, 2400f / page.width, 3200f / page.height)
                            val w = (page.width * scale).toInt().coerceAtLeast(1)
                            val h = (page.height * scale).toInt().coerceAtLeast(1)
                            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                            bmp.eraseColor(Color.WHITE)
                            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                            bmp
                        } finally {
                            page.close()
                        }
                    }
                    try {
                        sb.append(recognizer.process(InputImage.fromBitmap(bitmap, 0)).await().text)
                        sb.append('\n')
                    } finally {
                        bitmap.recycle()
                    }
                }
            } finally {
                renderer.close()
            }
        } finally {
            pfd.close()
        }
        return sb.toString()
    }
}

/** Reads paragraph text from a .docx file (a zip containing word/document.xml). */
object DocxReader {

    fun read(input: InputStream): String {
        val zip = ZipInputStream(input)
        var entry = zip.nextEntry
        while (entry != null) {
            if (entry.name == "word/document.xml") return parseXml(zip)
            entry = zip.nextEntry
        }
        throw IOException("This is not a valid .docx file")
    }

    private fun local(name: String): String = name.substringAfter(':')

    private fun parseXml(stream: InputStream): String {
        val parser = Xml.newPullParser()
        parser.setInput(stream, "UTF-8")
        val sb = StringBuilder()
        var inText = false
        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> when (local(parser.name)) {
                    "t" -> inText = true
                    "tab" -> sb.append(' ')
                    "br", "cr" -> sb.append('\n')
                }
                XmlPullParser.TEXT -> if (inText) sb.append(parser.text)
                XmlPullParser.END_TAG -> when (local(parser.name)) {
                    "t" -> inText = false
                    "p" -> sb.append('\n')
                }
            }
            event = parser.next()
        }
        return sb.toString()
    }
}
