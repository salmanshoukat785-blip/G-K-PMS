package com.ppsc.quiz

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import com.ppsc.quiz.ui.HomeScreen
import com.ppsc.quiz.ui.ImportScreen
import com.ppsc.quiz.ui.QuizScreen
import com.ppsc.quiz.ui.QuizTheme
import com.ppsc.quiz.ui.ResultScreen

class MainActivity : ComponentActivity() {
    private val vm: QuizViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            QuizTheme { AppRoot(vm) }
        }
    }
}

@Composable
private fun AppRoot(vm: QuizViewModel) {
    val paper = vm.currentPaper
    val question = vm.current

    // Phone's back button: quiz/result -> paper list
    BackHandler(enabled = paper != null || vm.importOpen) {
        if (paper == null) vm.closeImport() else vm.backToList()
    }

    when {
        paper == null && vm.importOpen -> ImportScreen(
            drafts = vm.drafts,
            busy = vm.importBusy,
            message = vm.importMessage,
            onPick = { vm.importFiles(it) },
            onUpdate = { id, change -> vm.updateDraft(id, change) },
            onCategoryAll = { vm.setCategoryForAll(it) },
            onSave = { vm.saveDrafts() },
            onClear = { vm.clearDrafts() },
            onBack = { vm.closeImport() }
        )
        paper == null -> HomeScreen(
            papers = vm.papers,
            query = vm.searchQuery,
            onQueryChange = { vm.searchQuery = it },
            shuffleOptions = vm.shuffleOptions,
            onShuffleChange = { vm.shuffleOptions = it },
            onOpen = {
                if (it.questions.isEmpty()) {
                    vm.notice = "Is category mein abhi MCQs nahi hain. Upload MCQs se add karein."
                } else vm.start(it)
            },
            onOpenQuestion = { p, questionId -> vm.start(p, questionId) },
            notice = vm.notice,
            onDismissNotice = { vm.notice = null },
            onUpload = { vm.openImport() }
        )
        vm.finished -> ResultScreen(
            score = vm.score,
            total = vm.questions.size,
            missed = vm.missed,
            onRetry = { vm.retry() },
            onBack = { vm.backToList() }
        )
        question != null -> {
            // Fetch Urdu for the visible question whenever translation is on
            LaunchedEffect(paper.id, vm.index, vm.translateOn) {
                if (vm.translateOn) vm.ensureTranslated(question)
            }
            QuizScreen(
                paperTitle = paper.title,
                question = question,
                position = vm.index + 1,
                total = vm.questions.size,
                selected = vm.selected,
                onlineExplanation = vm.onlineExplanation(question.id),
                onSelect = { vm.select(it) },
                onNext = { vm.next() },
                onExit = { vm.backToList() },
                translateOn = vm.translateOn,
                translating = vm.translating,
                translateError = vm.translateError,
                translated = { vm.translated(it) },
                onToggleTranslate = { vm.toggleTranslate() },
                onRetryTranslate = { vm.ensureTranslated(question) }
            )
        }
    }
}
