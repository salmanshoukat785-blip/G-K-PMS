package com.ppsc.quiz

import kotlin.random.Random

/** A category of questions (e.g. "A1. Pakistan: Economy, Society & Politics" or "Current Affairs"). */
data class Paper(
    val id: String,
    val title: String,
    val section: String,
    val questions: List<Question>,
    /** True when the whole category was created by an upload and has not been opened yet. */
    val isNew: Boolean = false
)

/** A question as stored. `answer` is a 0-based index into `options`. */
data class Question(
    val id: String,
    val number: Int,
    val text: String,
    val options: List<String>,
    val answer: Int,
    /** True for uploaded questions that the user has not seen yet. */
    val isNew: Boolean = false
) {
    /**
     * Returns a copy with options shuffled, so the correct answer is not always in the same place.
     * Options like "None of these" / "All of the above" keep their position.
     */
    fun shuffled(random: Random = Random.Default): ShownQuestion {
        val pinned = options.indices.filter { isPinned(options[it]) }.toSet()
        val movable = options.indices.filter { it !in pinned }
        val mixed = movable.map { options[it] }.shuffled(random)

        val result = options.toMutableList()
        movable.forEachIndexed { i, position -> result[position] = mixed[i] }

        return ShownQuestion(
            id = id,
            number = number,
            text = text,
            options = result,
            correctIndex = result.indexOf(options[answer]),
            isNew = isNew
        )
    }

    /** Same question with the original option order (when shuffle is turned off). */
    fun asStored(): ShownQuestion =
        ShownQuestion(id, number, text, options, answer, isNew)

    private fun isPinned(option: String): Boolean {
        val s = option.trim().lowercase()
        return s.startsWith("none of") || s.startsWith("all of the") || s.startsWith("all of these")
    }
}

/** A question ready to show on screen: options already in their final order. */
data class ShownQuestion(
    val id: String,
    val number: Int,
    val text: String,
    val options: List<String>,
    val correctIndex: Int,
    val isNew: Boolean = false
) {
    val correctLetter: Char get() = 'A' + correctIndex
    val correctText: String get() = options[correctIndex]
}

/** A question the user answered wrongly, kept for the review list on the result screen. */
data class MissedQuestion(
    val question: ShownQuestion,
    val chosenIndex: Int
)
