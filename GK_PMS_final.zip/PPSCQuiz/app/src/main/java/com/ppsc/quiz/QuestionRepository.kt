package com.ppsc.quiz

import android.content.Context
import org.json.JSONObject

/**
 * Loads categories: the built-in papers (assets/questions.json) plus anything the user
 * added (stored by UserStore). A user category with the same name as a built-in one is
 * merged into it.
 */
object QuestionRepository {

    private const val FILE_NAME = "questions.json"

    fun loadAll(context: Context): List<Paper> =
        merge(loadBuiltIn(context), UserStore.load(context))

    fun loadBuiltIn(context: Context): List<Paper> {
        val text = context.assets.open(FILE_NAME).bufferedReader(Charsets.UTF_8).use { it.readText() }
        return parse(text)
    }

    /** Separate from loadBuiltIn so it can be unit-tested without an Android Context. */
    fun parse(json: String): List<Paper> {
        val papersJson = JSONObject(json).getJSONArray("papers")
        return List(papersJson.length()) { p ->
            val paper = papersJson.getJSONObject(p)
            val paperId = paper.getString("id")
            val questionsJson = paper.getJSONArray("questions")
            Paper(
                id = paperId,
                title = paper.getString("title"),
                section = paper.optString("section", ""),
                questions = List(questionsJson.length()) { q ->
                    val item = questionsJson.getJSONObject(q)
                    val number = item.getInt("number")
                    parseQuestion(item, fallbackId = "$paperId:$number", number = number)
                }
            )
        }
    }

    fun parseQuestion(item: JSONObject, fallbackId: String, number: Int): Question {
        val optionsJson = item.getJSONArray("options")
        return Question(
            id = item.optString("id", fallbackId),
            number = number,
            text = item.getString("text"),
            options = List(optionsJson.length()) { optionsJson.getString(it) },
            answer = item.getInt("answer"),
            isNew = item.optBoolean("isNew", false),
            explanation = item.optString("explanation", "")
        )
    }

    /** User categories with the same name as a built-in one are appended to it. */
    fun merge(builtIn: List<Paper>, user: List<Paper>): List<Paper> {
        val result = builtIn.toMutableList()
        for (u in user) {
            val i = result.indexOfFirst { categoryKey(it.title) == categoryKey(u.title) }
            if (i >= 0) {
                val base = result[i]
                val start = base.questions.maxOfOrNull { it.number } ?: 0
                val added = u.questions.mapIndexed { n, q -> q.copy(number = start + n + 1) }
                result[i] = base.copy(questions = base.questions + added)
            } else {
                // e.g. an uploaded "Current Affairs" category is listed under section "A. Current Affairs"
                val sec = builtIn.firstOrNull {
                    normalize(it.section.substringAfter(". ", it.section)) == normalize(u.title)
                }?.section
                result.add(if (sec != null) u.copy(section = sec) else u)
            }
        }
        return result
    }

    /**
     * Key for comparing category names: ignores a leading code like "A1. " and the kind of
     * apostrophe, so an uploaded heading "Pakistan's Economic..." joins "A1. Pakistan's economic...".
     */
    fun categoryKey(s: String): String {
        val k = normalize(s.replace('\u2019', '\'').replace('\u2018', '\'').replace(Regex("^\\s*[A-Za-z]\\d{1,2}\\s*[.)]\\s+"), ""))
        return CategoryAliases.map[k] ?: k
    }

    /** Lower-case, single spaces: used to compare category names and detect duplicate questions.*/
    fun normalize(s: String): String = s.lowercase().replace(Regex("\\s+"), " ").trim()
}
