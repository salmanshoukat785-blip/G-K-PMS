package com.ppsc.quiz

data class SearchHit(val paper: Paper, val question: Question)

/**
 * Finds questions in all categories. Every word of [query] must appear somewhere in the
 * question text or its options (case-insensitive). Stops after [limit] results.
 */
fun searchQuestions(papers: List<Paper>, query: String, limit: Int = 100): List<SearchHit> {
    val words = query.lowercase().split(Regex("\\s+")).filter { it.isNotEmpty() }
    if (words.isEmpty()) return emptyList()

    val hits = ArrayList<SearchHit>()
    for (paper in papers) {
        for (q in paper.questions) {
            val haystack = (q.text + " " + q.options.joinToString(" ")).lowercase()
            if (words.all { haystack.contains(it) }) {
                hits.add(SearchHit(paper, q))
                if (hits.size >= limit) return hits
            }
        }
    }
    return hits
}
