package com.ppsc.quiz

import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/**
 * Online English -> Urdu translation. Needs internet.
 * 1) Google Translate public endpoint (no key, unofficial - may change)
 * 2) MyMemory free API as fallback (documented, daily limit for anonymous use)
 * To translate to another language, change TARGET_LANG (e.g. "pa" Punjabi, "hi" Hindi).
 */
object Translator {

    const val TARGET_LANG = "ur"

    suspend fun translate(text: String): String = withContext(Dispatchers.IO) {
        try {
            google(text)
        } catch (e: Exception) {
            myMemory(text)
        }
    }

    private fun google(text: String): String {
        val url = "https://translate.googleapis.com/translate_a/single" +
            "?client=gtx&sl=en&tl=$TARGET_LANG&dt=t&q=" + URLEncoder.encode(text, "UTF-8")
        val segments = JSONArray(httpGet(url)).getJSONArray(0)
        val sb = StringBuilder()
        for (i in 0 until segments.length()) {
            sb.append(segments.getJSONArray(i).optString(0, ""))
        }
        val result = sb.toString().trim()
        if (result.isEmpty()) throw IOException("Empty translation")
        return result
    }

    private fun myMemory(text: String): String {
        val url = "https://api.mymemory.translated.net/get?q=" +
            URLEncoder.encode(text, "UTF-8") + "&langpair=en%7C$TARGET_LANG"
        val result = JSONObject(httpGet(url)).getJSONObject("responseData")
            .getString("translatedText").trim()
        if (result.isEmpty()) throw IOException("Empty translation")
        return result
    }

    private fun httpGet(url: String): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            conn.setRequestProperty("User-Agent", "Mozilla/5.0")
            if (conn.responseCode != 200) throw IOException("HTTP ${conn.responseCode}")
            return conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }
}
