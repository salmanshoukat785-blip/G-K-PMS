package com.ppsc.quiz

import android.content.Context
import java.io.File
import java.io.IOException
import java.util.UUID
import org.json.JSONArray
import org.json.JSONObject

/** A question ready to be saved (produced by the upload/import step). `answer` is 0-based. */
data class ImportedQuestion(
    val text: String,
    val options: List<String>,
    val answer: Int,
    val explanation: String = ""
)

data class AddResult(val added: Int, val skipped: Int, val createdCategory: Boolean)

/**
 * User-added questions, saved in the app's private storage (files/user_data.json),
 * so they survive app updates. Questions are grouped by category name.
 */
object UserStore {

    private const val FILE = "user_data.json"

    fun load(context: Context): List<Paper> = try {
        val cats = readRoot(context).getJSONArray("categories")
        List(cats.length()) { c ->
            val cat = cats.getJSONObject(c)
            val title = cat.getString("title")
            val id = "user-" + slug(title)
            val qs = cat.getJSONArray("questions")
            Paper(
                id = id,
                title = title,
                section = "My uploads",
                isNew = cat.optBoolean("isNew", false),
                questions = List(qs.length()) { q ->
                    QuestionRepository.parseQuestion(qs.getJSONObject(q), "$id:${q + 1}", q + 1)
                }
            )
        }
    } catch (e: Exception) {
        emptyList()
    }

    /**
     * Adds questions to the category called [categoryTitle]; creates the category if it
     * does not exist (in the built-in papers or the user's own). Invalid questions and
     * duplicates (same question text in that category) are skipped.
     */
    fun addQuestions(context: Context, categoryTitle: String, items: List<ImportedQuestion>): AddResult {
        val title = categoryTitle.trim().ifEmpty { "Imported" }
        val key = QuestionRepository.categoryKey(title)

        val root = readRoot(context)
        val cats = root.getJSONArray("categories")

        var existing: JSONObject? = null
        for (i in 0 until cats.length()) {
            val c = cats.getJSONObject(i)
            if (QuestionRepository.categoryKey(c.getString("title")) == key) existing = c
        }

        // Texts already present in this category (built-in + user) for duplicate detection
        val seen = HashSet<String>()
        val builtInMatch = try {
            QuestionRepository.loadBuiltIn(context)
                .firstOrNull { QuestionRepository.categoryKey(it.title) == key }
        } catch (e: Exception) {
            null
        }
        builtInMatch?.questions?.forEach { seen.add(QuestionRepository.normalize(it.text)) }
        existing?.getJSONArray("questions")?.let { arr ->
            for (i in 0 until arr.length()) {
                seen.add(QuestionRepository.normalize(arr.getJSONObject(i).getString("text")))
            }
        }

        val fresh = ArrayList<JSONObject>()
        var skipped = 0
        for (item in items) {
            val valid = item.text.isNotBlank() && item.options.size == 4 &&
                item.options.all { it.isNotBlank() } && item.answer in 0..3
            if (!valid || !seen.add(QuestionRepository.normalize(item.text))) {
                skipped++
                continue
            }
            // Options are shuffled automatically when saved, so the right answer is not always "A".
            val options = item.options.map { it.trim() }
            val (mixed, answerIndex) = shuffleOptions(options, item.answer)
            // No explanation in the file: left empty, the quiz fetches one online (Wikipedia).
            val explanation = item.explanation.trim()
            fresh.add(
                JSONObject()
                    .put("id", UUID.randomUUID().toString())
                    .put("text", item.text.trim())
                    .put("options", JSONArray(mixed))
                    .put("answer", answerIndex)
                    .put("explanation", explanation)
                    .put("isNew", true)
            )
        }

        if (fresh.isEmpty()) return AddResult(0, skipped, false)

        val created = existing == null && builtInMatch == null
        val target = existing ?: JSONObject()
            .put("title", title)
            .put("isNew", created)
            .put("questions", JSONArray())
            .also { cats.put(it) }
        val arr = target.getJSONArray("questions")
        fresh.forEach { arr.put(it) }

        writeRoot(context, root)
        return AddResult(fresh.size, skipped, created)
    }

    /** Called when the user opens a category: removes its NEW labels. */
    fun clearNewFlags(context: Context, categoryTitle: String) {
        val key = QuestionRepository.categoryKey(categoryTitle)
        val root = readRoot(context)
        val cats = root.getJSONArray("categories")
        var changed = false
        for (i in 0 until cats.length()) {
            val cat = cats.getJSONObject(i)
            if (QuestionRepository.categoryKey(cat.getString("title")) != key) continue
            if (cat.optBoolean("isNew", false)) {
                cat.put("isNew", false)
                changed = true
            }
            val qs = cat.getJSONArray("questions")
            for (q in 0 until qs.length()) {
                val item = qs.getJSONObject(q)
                if (item.optBoolean("isNew", false)) {
                    item.put("isNew", false)
                    changed = true
                }
            }
        }
        if (changed) writeRoot(context, root)
    }

    /** Saves an explanation that was found online, so it is there next time (even offline). */
    fun setExplanation(context: Context, questionId: String, text: String) {
        val root = readRoot(context)
        val cats = root.getJSONArray("categories")
        for (c in 0 until cats.length()) {
            val qs = cats.getJSONObject(c).getJSONArray("questions")
            for (q in 0 until qs.length()) {
                val item = qs.getJSONObject(q)
                if (item.optString("id") == questionId && item.optString("explanation").isBlank()) {
                    item.put("explanation", text)
                    writeRoot(context, root)
                    return
                }
            }
        }
    }

    /** Random option order; "None of the above" / "All of the above" keep their place. */
    private fun shuffleOptions(options: List<String>, answer: Int): Pair<List<String>, Int> {
        val movable = options.indices.filter { i ->
            val s = options[i].trim().lowercase()
            !(s.startsWith("none of") || s.startsWith("all of the") || s.startsWith("all of these"))
        }
        val order = movable.shuffled()          // order[i] = original index placed at movable[i]
        val result = options.toMutableList()
        var newAnswer = answer
        movable.forEachIndexed { i, pos ->
            result[pos] = options[order[i]]
            if (order[i] == answer) newAnswer = pos
        }
        return result to newAnswer
    }

    private fun slug(title: String): String =
        Integer.toHexString(QuestionRepository.normalize(title).hashCode())

    private fun readRoot(context: Context): JSONObject {
        val file = File(context.filesDir, FILE)
        if (!file.exists()) return JSONObject().put("categories", JSONArray())
        return try {
            val root = JSONObject(file.readText(Charsets.UTF_8))
            if (!root.has("categories")) root.put("categories", JSONArray())
            root
        } catch (e: Exception) {
            // Unreadable file: keep a copy so nothing is lost, then start fresh.
            file.copyTo(File(context.filesDir, "user_data.corrupt.json"), overwrite = true)
            JSONObject().put("categories", JSONArray())
        }
    }

    /** Writes to a temp file first, so a crash cannot leave a half-written data file. */
    private fun writeRoot(context: Context, root: JSONObject) {
        val file = File(context.filesDir, FILE)
        val tmp = File(context.filesDir, "$FILE.tmp")
        tmp.writeText(root.toString(), Charsets.UTF_8)
        if (!tmp.renameTo(file)) throw IOException("Could not save $FILE")
    }
}
