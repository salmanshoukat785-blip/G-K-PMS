package com.ppsc.quiz

import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

/**
 * Online explanation from Wikipedia (free, no key, needs internet).
 * Searches for the correct answer + question and returns the first sentences of the best
 * matching article. Returns null when nothing suitable is found (the caller then shows a
 * simple "The correct answer is ..." line instead).
 */
object WikiExplainer {

    suspend fun explain(question: String, answer: String): String? = withContext(Dispatchers.IO) {
        try {
            lookup(question, answer)
        } catch (e: Exception) {
            null
        }
    }

    private fun lookup(question: String, answer: String): String? {
        val ans = answer.trim()
        if (ans.length < 4) return null     // "5", "x = 3" ... Wikipedia cannot explain these

        val all = question + ans
        val letters = all.count { it.isLetter() }
        val arabic = all.count { it in '\u0600'..'\u06FF' }
        val lang = if (letters > 0 && arabic * 100 / letters >= 30) "ur" else "en"

        val words = ans.split(Regex("[^\\p{L}\\p{N}]+")).filter { it.length >= 4 }.map { it.lowercase() }
        if (words.isEmpty()) return null

        val search = (ans + " " + question).take(250)
        val url = "https://$lang.wikipedia.org/w/api.php?action=query&generator=search" +
            "&gsrsearch=" + URLEncoder.encode(search, "UTF-8") +
            "&gsrlimit=3&prop=extracts&exintro=1&explaintext=1&exsentences=3&redirects=1" +
            "&format=json&utf8=1"
        val pages = JSONObject(httpGet(url)).optJSONObject("query")?.optJSONObject("pages") ?: return null

        val found = pages.keys().asSequence().map { pages.getJSONObject(it) }
            .sortedBy { it.optInt("index", 99) }
            .toList()
        for (p in found) {
            val extract = p.optString("extract", "").trim()
            val title = p.optString("title", "")
            if (extract.length < 40) continue
            val hay = (title + " " + extract).lowercase()
            if (words.none { hay.contains(it) }) continue   // article is not about the answer
            return "Correct answer: $ans.\n${extract.take(600)}\n(Source: Wikipedia - $title)"
        }
        return null
    }

    private fun httpGet(url: String): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            conn.setRequestProperty("User-Agent", "GK-PMS-StudyApp/1.0 (offline MCQ practice app)")
            if (conn.responseCode != 200) throw IOException("HTTP ${conn.responseCode}")
            return conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }
}
