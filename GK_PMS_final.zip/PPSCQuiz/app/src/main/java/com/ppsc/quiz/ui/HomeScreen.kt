package com.ppsc.quiz.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ppsc.quiz.Paper
import com.ppsc.quiz.SearchHit
import com.ppsc.quiz.searchQuestions

@Composable
fun HomeScreen(
    papers: List<Paper>,
    query: String,
    onQueryChange: (String) -> Unit,
    shuffleOptions: Boolean,
    onShuffleChange: (Boolean) -> Unit,
    onOpen: (Paper) -> Unit,
    onOpenQuestion: (Paper, String) -> Unit,
    notice: String?,
    onDismissNotice: () -> Unit,
    onUpload: () -> Unit
) {
    val searching = query.trim().length >= 2
    val hits = remember(papers, query) {
        if (searching) searchQuestions(papers, query) else emptyList()
    }

    Column(Modifier.fillMaxSize().background(QuizColors.Page)) {
        // Header
        Column(
            Modifier
                .fillMaxWidth()
                .background(QuizColors.Navy)
                .padding(horizontal = 20.dp, vertical = 22.dp)
        ) {
            Text("G-K PMS", color = QuizColors.Gold, fontSize = 13.sp,
                fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
            Text("Categories", color = Color.White, fontSize = 26.sp,
                fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 4.dp))
            Text("Tick the right answer to check it", color = Color(0xFFD8D3F0),
                fontSize = 14.sp, modifier = Modifier.padding(top = 4.dp))
        }

        // Upload button
        Button(
            onClick = onUpload,
            colors = ButtonDefaults.buttonColors(
                containerColor = QuizColors.Gold, contentColor = QuizColors.NavyDark),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 12.dp)
        ) {
            Text("＋  Upload MCQs (photo / PDF / Word)", fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(vertical = 4.dp))
        }

        // Result of the last upload
        if (notice != null) {
            Surface(
                color = QuizColors.GreenLight,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 12.dp)
            ) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.Top) {
                    Text(notice, color = QuizColors.Green, fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    Text("✕", color = QuizColors.Green,
                        modifier = Modifier.clickable { onDismissNotice() }.padding(start = 8.dp))
                }
            }
        }

        // Search
        OutlinedTextField(
            value = query,
            onValueChange = onQueryChange,
            singleLine = true,
            placeholder = { Text("Search all questions…") },
            trailingIcon = if (query.isNotEmpty()) {
                @Composable {
                    Text("✕", fontSize = 18.sp, color = QuizColors.Navy,
                        modifier = Modifier.clickable { onQueryChange("") }.padding(12.dp))
                }
            } else null,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)
        )

        if (searching) {
            SearchResults(hits, onOpenQuestion, Modifier.weight(1f))
        } else {
            CategoryList(papers, shuffleOptions, onShuffleChange, onOpen, Modifier.weight(1f))
        }
    }
}

@Composable
private fun CategoryList(
    papers: List<Paper>,
    shuffleOptions: Boolean,
    onShuffleChange: (Boolean) -> Unit,
    onOpen: (Paper) -> Unit,
    modifier: Modifier
) {
    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Surface(color = QuizColors.Card, shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()) {
                Row(
                    Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("Shuffle options", fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                        Text("A, B, C, D order changes every time", fontSize = 13.sp,
                            color = Color(0xFF5B5675))
                    }
                    Switch(checked = shuffleOptions, onCheckedChange = onShuffleChange)
                }
            }
        }

        if (papers.isEmpty()) {
            item {
                Text("No categories found. Check assets/questions.json",
                    color = QuizColors.Red, modifier = Modifier.padding(4.dp))
            }
        }

        papers.groupBy { it.section }.forEach { (sectionName, group) ->
            if (sectionName.isNotBlank()) {
                item(key = "section-$sectionName") {
                    Text(sectionName, fontWeight = FontWeight.Bold, fontSize = 15.sp,
                        color = QuizColors.Navy, modifier = Modifier.padding(top = 8.dp, start = 4.dp))
                }
            }
            items(group, key = { it.id }) { paper ->
                Surface(
                    color = QuizColors.Card,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().clickable { onOpen(paper) }
                ) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(paper.title, fontWeight = FontWeight.Bold, fontSize = 17.sp,
                                color = QuizColors.Navy)
                            Text("${paper.questions.size} questions", fontSize = 14.sp,
                                color = Color(0xFF5B5675), modifier = Modifier.padding(top = 4.dp))
                        }
                        badgeText(paper)?.let { NewBadge(it) }
                    }
                }
            }
        }
    }
}

@Composable
private fun SearchResults(
    hits: List<SearchHit>,
    onOpenQuestion: (Paper, String) -> Unit,
    modifier: Modifier
) {
    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(
                when {
                    hits.isEmpty() -> "No questions found"
                    hits.size >= 100 -> "Showing first 100 results - type more words to narrow down"
                    else -> "${hits.size} results"
                },
                color = Color(0xFF5B5675), fontSize = 13.sp
            )
        }
        items(hits, key = { it.question.id }) { hit ->
            Surface(
                color = QuizColors.Card,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().clickable { onOpenQuestion(hit.paper, hit.question.id) }
            ) {
                Column(Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(hit.paper.title, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                            color = QuizColors.Gold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f))
                        if (hit.question.isNew) NewBadge("NEW")
                    }
                    Text("Q${hit.question.number}. ${hit.question.text}", fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold, color = QuizColors.Ink,
                        maxLines = 3, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(top = 4.dp))
                }
            }
        }
    }
}

private fun badgeText(p: Paper): String? {
    val n = p.questions.count { it.isNew }
    return when {
        p.isNew -> "NEW • نیا"
        n > 0 -> "$n new • نئے"
        else -> null
    }
}

@Composable
fun NewBadge(text: String) {
    Surface(color = QuizColors.Gold, shape = RoundedCornerShape(8.dp)) {
        Text(text, color = QuizColors.NavyDark, fontSize = 11.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp))
    }
}
