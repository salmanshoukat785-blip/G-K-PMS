package com.ppsc.quiz.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.toMutableStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ppsc.quiz.DraftQuestion

private val LETTERS = "ABCD"
private val MIME_TYPES = arrayOf(
    "image/*",
    "application/pdf",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
)

@Composable
fun ImportScreen(
    drafts: List<DraftQuestion>,
    busy: String?,
    message: String?,
    onPick: (List<Uri>) -> Unit,
    onUpdate: (String, (DraftQuestion) -> DraftQuestion) -> Unit,
    onCategoryAll: (String) -> Unit,
    onSave: () -> Unit,
    onClear: () -> Unit,
    onBack: () -> Unit
) {
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) onPick(uris)
    }
    var editingId by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize().background(QuizColors.Page)) {
        // Top bar
        Row(
            Modifier.fillMaxWidth().background(QuizColors.Navy).padding(horizontal = 8.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("‹", color = Color.White, fontSize = 30.sp,
                modifier = Modifier.clickable { onBack() }.padding(horizontal = 12.dp))
            Text("Upload MCQs", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f))
            if (drafts.isNotEmpty() && busy == null) {
                Text("Clear", color = QuizColors.Gold, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clickable { onClear() }.padding(horizontal = 12.dp))
            }
        }

        when {
            busy != null -> Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    CircularProgressIndicator(color = QuizColors.Navy)
                    Text(busy, color = QuizColors.Ink, fontSize = 15.sp)
                }
            }

            drafts.isEmpty() -> Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Surface(color = QuizColors.Card, shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Add MCQs from files", fontWeight = FontWeight.Bold, fontSize = 17.sp,
                            color = QuizColors.Navy)
                        Text("• Photos / screenshots (JPG, PNG)", fontSize = 14.sp)
                        Text("• PDF files", fontSize = 14.sp)
                        Text("• Word files (.docx)", fontSize = 14.sp)
                        Text("You can pick many files at once. Questions, options and answers are " +
                            "found automatically and put in categories. You can check and fix " +
                            "everything before saving.", fontSize = 13.sp, color = Color(0xFF5B5675),
                            modifier = Modifier.padding(top = 6.dp))
                        Text("Photos and PDFs are read with OCR (English text). Answers must be " +
                            "written in the file, like “Answer: C”.", fontSize = 13.sp,
                            color = Color(0xFF5B5675))
                    }
                }
                Button(
                    onClick = { picker.launch(MIME_TYPES) },
                    colors = ButtonDefaults.buttonColors(containerColor = QuizColors.Navy),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Choose files", fontSize = 16.sp, modifier = Modifier.padding(vertical = 6.dp)) }
                if (message != null) {
                    Text(message, color = QuizColors.Red, fontSize = 14.sp)
                }
            }

            else -> {
                val included = drafts.filter { it.include }
                val needAnswer = included.count { it.answer == null }
                val invalid = included.count { it.answer != null && !it.isValid }
                val canSave = included.isNotEmpty() && included.all { it.isValid }
                var allCategory by remember { mutableStateOf("") }

                Column(Modifier.fillMaxSize()) {
                    Column(Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
                        Text("${included.size} of ${drafts.size} questions selected",
                            fontWeight = FontWeight.Bold, fontSize = 16.sp, color = QuizColors.Navy)
                        if (needAnswer > 0) {
                            Text("$needAnswer need an answer - tap A / B / C / D on them",
                                color = QuizColors.Red, fontSize = 13.sp)
                        }
                        if (invalid > 0) {
                            Text("$invalid have empty options - tap the question to edit",
                                color = QuizColors.Red, fontSize = 13.sp)
                        }
                        if (message != null) {
                            Text(message, color = Color(0xFF5B5675), fontSize = 12.sp,
                                modifier = Modifier.padding(top = 4.dp))
                        }
                        Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(
                                value = allCategory,
                                onValueChange = { allCategory = it },
                                singleLine = true,
                                placeholder = { Text("Same category for all…") },
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.weight(1f)
                            )
                            TextButton(onClick = { onCategoryAll(allCategory) },
                                enabled = allCategory.isNotBlank()) { Text("Apply") }
                        }
                    }

                    LazyColumn(
                        Modifier.weight(1f),
                        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(drafts, key = { it.id }) { d ->
                            DraftCard(
                                d = d,
                                onToggle = { onUpdate(d.id) { it.copy(include = !it.include) } },
                                onAnswer = { a -> onUpdate(d.id) { it.copy(answer = a) } },
                                onEdit = { editingId = d.id }
                            )
                        }
                    }

                    Row(
                        Modifier.fillMaxWidth().padding(16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedButton(
                            onClick = { picker.launch(MIME_TYPES) },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f)
                        ) { Text("Add more files", modifier = Modifier.padding(vertical = 4.dp)) }
                        Button(
                            onClick = onSave,
                            enabled = canSave,
                            colors = ButtonDefaults.buttonColors(containerColor = QuizColors.Navy),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f)
                        ) { Text("Save ${included.size}", modifier = Modifier.padding(vertical = 4.dp)) }
                    }
                }
            }
        }
    }

    // Edit dialog
    val editing = drafts.firstOrNull { it.id == editingId }
    if (editing != null) {
        EditDialog(
            draft = editing,
            onDismiss = { editingId = null },
            onSave = { updated ->
                onUpdate(editing.id) { updated }
                editingId = null
            }
        )
    }
}

@Composable
private fun DraftCard(
    d: DraftQuestion,
    onToggle: () -> Unit,
    onAnswer: (Int) -> Unit,
    onEdit: () -> Unit
) {
    Surface(
        color = if (d.include) QuizColors.Card else Color(0xFFEDEDED),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(Modifier.padding(end = 12.dp, top = 6.dp, bottom = 10.dp)) {
            Checkbox(checked = d.include, onCheckedChange = { onToggle() })
            Column(Modifier.weight(1f).clickable { onEdit() }.padding(top = 8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(d.category, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = QuizColors.Gold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(d.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = QuizColors.Ink,
                    maxLines = 3, overflow = TextOverflow.Ellipsis)
                d.options.forEachIndexed { i, o ->
                    val right = d.answer == i
                    Text("${LETTERS[i]}. ${o.ifBlank { "(empty)" }}", fontSize = 13.sp,
                        color = if (right) QuizColors.Green else if (o.isBlank()) QuizColors.Red else QuizColors.Ink,
                        fontWeight = if (right) FontWeight.Bold else FontWeight.Normal,
                        maxLines = 2, overflow = TextOverflow.Ellipsis)
                }
                if (d.answer == null) {
                    Row(verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Answer:", fontSize = 13.sp, color = QuizColors.Red)
                        LETTERS.forEachIndexed { i, c ->
                            AnswerChip(c, selected = false, onClick = { onAnswer(i) })
                        }
                    }
                }
                Text(d.source, fontSize = 11.sp, color = Color(0xFF8A86A3), maxLines = 1,
                    overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun AnswerChip(letter: Char, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(34.dp)
            .background(if (selected) QuizColors.Green else Color.White, CircleShape)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text("$letter", fontWeight = FontWeight.Bold, fontSize = 14.sp,
            color = if (selected) Color.White else QuizColors.Navy)
    }
}

@Composable
private fun EditDialog(
    draft: DraftQuestion,
    onDismiss: () -> Unit,
    onSave: (DraftQuestion) -> Unit
) {
    var text by remember(draft.id) { mutableStateOf(draft.text) }
    val options = remember(draft.id) { draft.options.toMutableStateList() }
    var answer by remember(draft.id) { mutableStateOf(draft.answer) }
    var category by remember(draft.id) { mutableStateOf(draft.category) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Edit question") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = text, onValueChange = { text = it },
                    label = { Text("Question") }, modifier = Modifier.fillMaxWidth())
                options.forEachIndexed { i, o ->
                    OutlinedTextField(value = o, onValueChange = { options[i] = it },
                        label = { Text("Option ${LETTERS[i]}") }, modifier = Modifier.fillMaxWidth())
                }
                Text("Correct answer", fontSize = 13.sp, color = Color(0xFF5B5675))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    LETTERS.forEachIndexed { i, c ->
                        AnswerChip(c, selected = answer == i, onClick = { answer = i })
                    }
                }
                OutlinedTextField(value = category, onValueChange = { category = it },
                    label = { Text("Category") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onSave(draft.copy(
                    text = text.trim(),
                    options = options.map { it.trim() },
                    answer = answer,
                    category = category.trim().ifEmpty { draft.category }
                ))
            }) { Text("OK") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
