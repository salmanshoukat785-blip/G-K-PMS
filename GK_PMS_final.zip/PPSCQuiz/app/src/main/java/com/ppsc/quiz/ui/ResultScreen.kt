package com.ppsc.quiz.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ppsc.quiz.MissedQuestion

@Composable
fun ResultScreen(
    score: Int,
    total: Int,
    missed: List<MissedQuestion>,
    onRetry: () -> Unit,
    onBack: () -> Unit
) {
    val percent = if (total == 0) 0 else score * 100 / total
    val message = when {
        percent >= 80 -> "Excellent work!"
        percent >= 60 -> "Good, keep practising"
        else -> "Needs more practice"
    }

    LazyColumn(
        Modifier.fillMaxSize().background(QuizColors.Page),
        contentPadding = PaddingValues(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Header with score
        item {
            Column(
                Modifier.fillMaxWidth().background(QuizColors.Navy).padding(vertical = 32.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("RESULT", color = QuizColors.Gold, fontSize = 13.sp,
                    fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                Text("$score / $total", color = Color.White, fontSize = 52.sp,
                    fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
                Text("$percent%", color = QuizColors.Gold, fontSize = 24.sp,
                    fontWeight = FontWeight.Bold)
                Text(message, color = Color(0xFFD8D3F0), fontSize = 15.sp,
                    modifier = Modifier.padding(top = 6.dp))
            }
        }

        // Correct / wrong counts
        item {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                StatBox("Correct", score, QuizColors.Green, QuizColors.GreenLight, Modifier.weight(1f))
                StatBox("Wrong", total - score, QuizColors.Red, QuizColors.RedLight, Modifier.weight(1f))
            }
        }

        // Buttons
        item {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = onRetry,
                    colors = ButtonDefaults.buttonColors(containerColor = QuizColors.Navy),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f)
                ) { Text("Try again", modifier = Modifier.padding(vertical = 4.dp)) }
                OutlinedButton(
                    onClick = onBack,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f)
                ) { Text("All papers", modifier = Modifier.padding(vertical = 4.dp)) }
            }
        }

        // Review of mistakes
        if (missed.isNotEmpty()) {
            item {
                Text("Review mistakes (${missed.size})", fontWeight = FontWeight.Bold,
                    fontSize = 18.sp, color = QuizColors.Navy,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
            }
            items(missed, key = { it.question.id }) { m ->
                MissedCard(m, Modifier.padding(horizontal = 16.dp))
            }
        } else {
            item {
                Text("Perfect score - nothing to review!", color = QuizColors.Green,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(horizontal = 16.dp))
            }
        }
    }
}

@Composable
private fun StatBox(label: String, value: Int, accent: Color, bg: Color, modifier: Modifier) {
    Surface(color = bg, shape = RoundedCornerShape(14.dp), modifier = modifier) {
        Column(Modifier.padding(vertical = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("$value", color = accent, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Text(label, color = accent, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun MissedCard(m: MissedQuestion, modifier: Modifier) {
    val q = m.question
    Surface(color = QuizColors.Card, shape = RoundedCornerShape(14.dp), modifier = modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Q${q.number}. ${q.text}", fontWeight = FontWeight.SemiBold,
                fontSize = 16.sp, color = QuizColors.Ink)
            Text("✗ Your answer: ${'A' + m.chosenIndex} — ${q.options[m.chosenIndex]}",
                color = QuizColors.Red, fontSize = 14.sp)
            Text("✓ Correct: ${q.correctLetter} — ${q.correctText}",
                color = QuizColors.Green, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}
