package com.ppsc.quiz.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object QuizColors {
    val Navy = Color(0xFF241B5E)
    val NavyDark = Color(0xFF16103D)
    val Gold = Color(0xFFC9A55C)
    val Page = Color(0xFFFDFAF3)
    val Card = Color(0xFFEFEBFA)
    val Green = Color(0xFF2E7D4F)
    val GreenLight = Color(0xFFDDF3E4)
    val Red = Color(0xFFC0392B)
    val RedLight = Color(0xFFFADBD8)
    val Ink = Color(0xFF1E1B2E)
}

@Composable
fun QuizTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = QuizColors.Navy,
            onPrimary = Color.White,
            background = QuizColors.Page,
            surface = QuizColors.Page,
            onSurface = QuizColors.Ink
        ),
        content = content
    )
}
