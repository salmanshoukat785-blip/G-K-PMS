# GK PMS - GitHub par upload aur APK banane ki guide (Roman Urdu)

## Tareeqa 1: ZIP upload karein, APK khud ban jayegi (aasan)

1. github.com par **New repository** banayein (jaise `gk-pms`). Repo **empty** rakhein.
2. **Ek dafa** workflow file add karein:
   - Repo mein **Add file -> Create new file** dabayein.
   - File ka naam is tarah likhein: `.github/workflows/build-apk.yml`
     (slash likhne se folders khud ban jate hain).
   - `build-apk.yml` file ka poora text yahan paste karein, phir **Commit changes**.
   - Is par pehli run laal (fail) ho sakti hai, kyunke abhi project nahi hai. Yeh theek hai.
3. Ab **Add file -> Upload files** dabayein aur `PPSCQuiz_final.zip` upload karein.
   **ZIP ko extract nahi karna**, seedha zip hi upload karein. Phir **Commit changes**.
4. **Actions** tab kholein. "Build GK PMS APK" chalega (5-10 minute). Pehle zip khulta hai, phir APK banti hai.
5. Sabz tick aane par repo ke **Releases** (right side) mein jayein. Wahan `GK-PMS.apk` download karein.
   (Actions run ke **Artifacts** mein bhi `GK-PMS-apk` milti hai.)

Jab bhi nayi zip upload karenge, nayi APK khud ban jayegi. Naya build alag Release mein aayega.

## Tareeqa 2: Files extract karke (git se)
```bash
git init
git add .
git commit -m "GK PMS app"
git branch -M main
git remote add origin https://github.com/APKA_USERNAME/gk-pms.git
git push -u origin main
```
`.github` folder (hidden) zaroor upload hona chahiye. Phir wahi Actions -> Releases wale qadam.

## Phone par install
1. APK phone mein copy karein aur kholein.
2. Rok aaye to Settings mein **Install unknown apps** allow karein.
3. Install karein. Yeh debug APK hai, is liye Play Protect warning aa sakti hai.

## Agar build fail ho
Actions tab mein laal run kholein, error ki lines copy karke mujhe bhej dein.

## Naye questions
Yeh ab app ke andar se hota hai: Home -> **Upload MCQs** (photo / PDF / Word). Code badalne ki zaroorat nahi.
