package com.ppsc.quiz

/** One question found in a text. `answer` is a 0-based index, or null when the text had no answer. */
data class ParsedQuestion(
    val number: Int,
    val text: String,
    val options: List<String>,   // always 4 entries (missing ones are "")
    val answer: Int?,
    val category: String?        // taken from a heading in the text, if any
)

/**
 * Turns plain text (from Word, or OCR of photos/PDFs) into questions.
 * Understands: "1.", "Q1.", "Question 1:", "A1-Q1." question markers; A-D options written as
 * "A.", "A)", "(A)", "A text", on separate lines or inline; answers written as "Answer: C",
 * "Correct Answer: A. text", "Ans: b", "ANSWER C - text"; answer-key tables ("1. B 2. C");
 * and headings like "A1. Pakistan: Economy" or "Topic: Physics" as categories.
 */
object McqParser {

    private val Q_START = Regex(
        """^((?:[A-Za-z]{1,2}\d{1,3}-)?Q(?:uestion)?\s*\.?\s*)?(\d{1,4})\s*[.):\-–](?:\s+(.*)|$)""",
        RegexOption.IGNORE_CASE
    )
    private val OPT_PUNCT = Regex("""^\(?([A-Da-d])(?:\)\s*|[.:\-]\s+|[.:\-]$|\s+[.:\-]\s+)(.*)$""")
    private val OPT_BARE = Regex("""^([A-D])\s+(\S.*)$""")
    private val OPT_LONE = Regex("""^\(?([A-Da-d])[.)]?$""")
    private val INLINE = Regex("""(?:^|\s)\(?([A-Da-d])(?:\)|\.)\s""")
    private val ANSWER = Regex(
        """^\W*(?:correct\s+)?(?:answer|ans)\b\s*(?:is|key)?\s*([:\-–—.])?\s*(.*)$""",
        RegexOption.IGNORE_CASE
    )
    private val LETTER = Regex("""^\(?([A-Da-d])(?:\b|\))""")
    private val EXPL = Regex("""^\W*(?:simple\s+)?(?:explanation|solution|reason)\b""", RegexOption.IGNORE_CASE)
    private val KEY_LINE = Regex("""^(?:\d{1,4}\s*[.\-–:)]?\s*\(?[A-Da-d]\)?[\s,;|]*)+$""")
    private val KEY_PAIR = Regex("""(\d{1,4})\s*[.\-–:)]?\s*\(?([A-Da-d])\)?""")
    private val LONE_NUM = Regex("""^\d{1,3}$""")
    private val HEAD_B = Regex(
        """^(?:category|topic|subject|section|chapter|unit)\s*[:\-–]\s*(.{2,80})$""",
        RegexOption.IGNORE_CASE
    )
    private val HEAD_A = Regex("""^[A-Za-z]\d{1,2}\s*[.)]\s+(.{3,80})$""")
    private val HEAD_A2 = Regex("""^[A-Ka-k]\s*[.)]\s+(.{3,60})$""")
    private val WORDS = Regex("""[A-Za-z\u0600-\u06FF]{3,}""")
    private val NOISE_WORDS = Regex("""compiled by|www\.|https?:|©""", RegexOption.IGNORE_CASE)
    private val PAGE = Regex("""^page\s*\d+$""", RegexOption.IGNORE_CASE)
    private val BULLET = Regex("""^[•●▪◦\u2022]+\s*""")
    private val SPACES = Regex("""\s+""")

    fun parse(text: String): List<ParsedQuestion> = Run().execute(text)

    private fun clean(raw: String): String {
        val s = raw.replace("\u200b", "").replace('\u00a0', ' ').replace("*", "")
        return SPACES.replace(BULLET.replace(s.trim(), ""), " ").trim()
    }

    private fun isNoise(line: String): Boolean =
        line.contains('·') || NOISE_WORDS.containsMatchIn(line) || PAGE.matches(line)

    private fun titleCase(raw: String): String {
        var s = raw.trim().trimEnd(':').trim()
        if (s.any { it.isLetter() } && s == s.uppercase()) {
            s = s.split(' ').joinToString(" ") { w -> w.take(1).uppercase() + w.drop(1).lowercase() }
        }
        return s
    }

    private fun endsWithPunct(text: String): Boolean {
        val t = text.trimEnd()
        return t.isNotEmpty() && t.last() in "?:._)…-"
    }

    private enum class State { NONE, Q, OPTS, DONE }

    private class Building(var number: Int, var text: String, val category: String?) {
        val opts = LinkedHashMap<Char, String>()
        var ansLetter: Char? = null
        var ansText: String? = null
    }

    private class Run {
        val out = ArrayList<ParsedQuestion>()
        var cur: Building? = null
        var state = State.NONE
        var heading: String? = null
        val keyMap = HashMap<Int, Char>()
        var pendLetter: Char? = null
        var pendNum: Int? = null
        var lastN: Int? = null
        var lastLetter: Char? = null

        fun finish() {
            val c = cur ?: return
            cur = null
            if (c.text.isBlank() || c.opts.size < 2) return
            val options = "ABCD".map { c.opts[it] ?: "" }
            var ans: Int? = null
            val letter = c.ansLetter
            val atext = c.ansText
            if (letter != null) {
                ans = "ABCD".indexOf(letter)
            } else if (atext != null) {
                val na = atext.lowercase().trim()
                for (i in options.indices) {
                    val no = options[i].lowercase().trim()
                    if (no.isNotEmpty() && (no == na || na.startsWith(no) || no.startsWith(na))) {
                        ans = i
                        break
                    }
                }
            }
            out.add(ParsedQuestion(c.number, c.text.trim(), options, ans, c.category))
        }

        fun start(n: Int, t: String) {
            finish()
            cur = Building(n, t, heading)
            state = State.Q
            lastN = n
            pendLetter = null
            pendNum = null
            lastLetter = null
        }

        fun tryHeading(line: String) {
            for (rx in listOf(HEAD_B, HEAD_A, HEAD_A2)) {
                val m = rx.find(line)
                if (m != null) {
                    heading = titleCase(m.groupValues[1])
                    return
                }
            }
        }

        fun execute(text: String): List<ParsedQuestion> {
            for (raw in text.lineSequence()) {
                val line = clean(raw)
                if (line.isEmpty() || isNoise(line)) continue

                // Answer-key table, e.g. "1. B 2. C 3. A"
                if (KEY_LINE.matches(line)) {
                    for (m in KEY_PAIR.findAll(line)) {
                        keyMap[m.groupValues[1].toInt()] = m.groupValues[2].uppercase()[0]
                    }
                    continue
                }

                // Answer line
                val ma = ANSWER.find(line)
                if (ma != null) {
                    val delim = ma.groupValues[1]
                    val rest = ma.groupValues[2].trim()
                    val lm = if (rest.isNotEmpty()) LETTER.find(rest) else null
                    if (lm != null || (delim.isNotEmpty() && rest.isNotEmpty())) {
                        val c = cur
                        if (c != null) {
                            if (lm != null) c.ansLetter = lm.groupValues[1].uppercase()[0] else c.ansText = rest
                            state = State.DONE
                            pendLetter = null
                        }
                        continue
                    }
                    if (rest.isEmpty()) continue   // e.g. "Answer Key" heading
                }
                if (EXPL.containsMatchIn(line)) continue

                // Text of an option whose letter was on the previous line
                val pl = pendLetter
                val pc = cur
                if (pl != null && pc != null) {
                    pc.opts[pl] = line
                    lastLetter = pl
                    pendLetter = null
                    state = State.OPTS
                    continue
                }

                // New question
                val mq = Q_START.find(line)
                if (mq != null) {
                    val n = mq.groupValues[2].toInt()
                    val rest = mq.groupValues[3].trim()
                    val strong = mq.groupValues[1].isNotEmpty()
                    val hasWords = WORDS.containsMatchIn(rest)
                    val ln = lastN
                    val inSequence = ln == null || n == 1 || (n > ln && n <= ln + 60)
                    if (strong || ((hasWords || rest.isEmpty()) && inSequence)) {
                        start(n, rest)
                        continue
                    }
                }

                // Options
                val c1 = cur
                if (c1 != null && (state == State.Q || state == State.OPTS)) {
                    val used = c1.opts

                    // Several options on one line: "A) x B) y C) z D) w"
                    val marks = INLINE.findAll(line).toList()
                    if (marks.size >= 2 && marks[0].range.first == 0 && used.size + marks.size <= 4) {
                        val letters = marks.map { it.groupValues[1].uppercase()[0] }
                        if (letters.none { it in used }) {
                            for (i in marks.indices) {
                                val end = if (i + 1 < marks.size) marks[i + 1].range.first else line.length
                                used[letters[i]] = line.substring(marks[i].range.last + 1, end).trim()
                                lastLetter = letters[i]
                            }
                            state = State.OPTS
                            continue
                        }
                    }

                    val mo = OPT_PUNCT.find(line)
                    if (mo != null) {
                        val l = mo.groupValues[1].uppercase()[0]
                        if (l !in used && used.size < 4) {
                            val t = mo.groupValues[2].trim()
                            if (t.isNotEmpty()) {
                                used[l] = t
                                lastLetter = l
                            } else {
                                pendLetter = l
                            }
                            state = State.OPTS
                            continue
                        }
                    }

                    val ml = OPT_LONE.find(line)
                    if (ml != null) {
                        val l = ml.groupValues[1].uppercase()[0]
                        if (l !in used && used.size < 4 &&
                            (used.isNotEmpty() || endsWithPunct(c1.text) || l == 'A')
                        ) {
                            pendLetter = l
                            state = State.OPTS
                            continue
                        }
                    }

                    val mb = OPT_BARE.find(line)
                    if (mb != null) {
                        val l = mb.groupValues[1][0]
                        if (l !in used && used.size < 4 &&
                            (used.isNotEmpty() || (l == 'A' && endsWithPunct(c1.text)))
                        ) {
                            used[l] = mb.groupValues[2].trim()
                            lastLetter = l
                            state = State.OPTS
                            continue
                        }
                    }
                }

                // A lone number is the number badge of the next question (photos of cards)
                val c2 = cur
                val atBoundary = c2 == null || state == State.DONE ||
                    (state == State.OPTS && c2.opts.size >= 4)
                if (LONE_NUM.matches(line) && atBoundary) {
                    pendNum = line.toInt()
                    continue
                }
                val pn = pendNum
                if (pn != null && atBoundary) {
                    start(pn, line)
                    continue
                }

                // Continuation lines
                if (c2 != null && state == State.Q) {
                    c2.text = (c2.text + " " + line).trim()
                    continue
                }
                val ll = lastLetter
                if (c2 != null && state == State.OPTS && c2.opts.size < 4 && ll != null) {
                    c2.opts[ll] = (c2.opts[ll] ?: "") + " " + line
                    continue
                }

                // Anything else between questions may be a heading
                if (atBoundary) tryHeading(line)
            }
            finish()

            // Apply answer-key table to questions that have no answer yet
            return out.map { q ->
                val k = keyMap[q.number]
                if (q.answer == null && k != null) q.copy(answer = "ABCD".indexOf(k)) else q
            }
        }
    }
}
