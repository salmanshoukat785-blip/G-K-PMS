package com.ppsc.quiz

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private fun loadAllSafely(app: Application): List<Paper> = try {
    QuestionRepository.loadAll(app)
} catch (e: Exception) {
    emptyList()
}

/** Holds all quiz state, so it survives screen rotation (options are not re-shuffled). */
class QuizViewModel(app: Application) : AndroidViewModel(app) {

    /** All categories (built-in + user added). */
    var papers by mutableStateOf(loadAllSafely(app))
        private set

    /** Reload categories from storage (call after new questions were saved). */
    fun refreshPapers() {
        papers = loadAllSafely(getApplication())
    }

    // ---------- Search ----------
    var searchQuery by mutableStateOf("")

    // ---------- Quiz ----------

    /** When true, options are shuffled every time a category is started. */
    var shuffleOptions by mutableStateOf(true)

    var currentPaper by mutableStateOf<Paper?>(null)
        private set
    var questions by mutableStateOf<List<ShownQuestion>>(emptyList())
        private set
    var index by mutableIntStateOf(0)
        private set
    /** Index of the option the user tapped for the current question, or null if not answered yet. */
    var selected by mutableStateOf<Int?>(null)
        private set
    var score by mutableIntStateOf(0)
        private set
    var finished by mutableStateOf(false)
        private set

    private val _missed = mutableStateListOf<MissedQuestion>()
    /** Questions answered wrongly in the current attempt, in the order they were answered. */
    val missed: List<MissedQuestion> get() = _missed

    val current: ShownQuestion? get() = questions.getOrNull(index)

    /**
     * Starts a category. If [startAtQuestionId] is given (tapped from search), the quiz opens
     * at that question. NEW labels are shown during this attempt and cleared afterwards.
     */
    fun start(paper: Paper, startAtQuestionId: String? = null) {
        val hadNew = paper.isNew || paper.questions.any { it.isNew }
        currentPaper = paper
        questions = paper.questions.map { if (shuffleOptions) it.shuffled() else it.asStored() }
        index = startAtQuestionId
            ?.let { id -> questions.indexOfFirst { it.id == id } }
            ?.takeIf { it >= 0 } ?: 0
        selected = null
        score = 0
        _missed.clear()
        finished = false

        if (hadNew) {
            try {
                UserStore.clearNewFlags(getApplication(), paper.title)
                refreshPapers()
            } catch (e: Exception) {
                // Not critical: the NEW label just stays until next time.
            }
        }
    }

    /** Only the first tap counts; the answer is locked after that. */
    fun select(optionIndex: Int) {
        val q = current ?: return
        if (selected != null) return
        selected = optionIndex
        if (optionIndex == q.correctIndex) score++ else _missed.add(MissedQuestion(q, optionIndex))
    }

    fun next() {
        if (index + 1 < questions.size) {
            index++
            selected = null
        } else {
            finished = true
        }
    }

    fun retry() {
        val id = currentPaper?.id ?: return
        papers.firstOrNull { it.id == id }?.let { start(it) }
    }

    fun backToList() {
        currentPaper = null
        questions = emptyList()
        finished = false
    }

    // ---------- Online translation (English -> Urdu) ----------

    /** When true, the quiz screen shows Urdu under the question and every option. */
    var translateOn by mutableStateOf(false)
        private set
    var translating by mutableStateOf(false)
        private set
    var translateError by mutableStateOf(false)
        private set

    /** English text -> Urdu text. Kept in memory so each text is fetched only once. */
    private val translationCache = mutableStateMapOf<String, String>()

    fun translated(text: String): String? = translationCache[text]

    fun toggleTranslate() {
        translateOn = !translateOn
        translateError = false
    }

    /** Fetches Urdu for the question and its options (only what is not cached yet). */
    fun ensureTranslated(q: ShownQuestion) {
        val missing = (listOf(q.text) + q.options).filter { it !in translationCache }
        if (missing.isEmpty()) return
        translating = true
        translateError = false
        viewModelScope.launch {
            try {
                missing.map { t -> async { t to Translator.translate(t) } }
                    .awaitAll()
                    .forEach { (english, urdu) -> translationCache[english] = urdu }
            } catch (e: Exception) {
                translateError = true
            } finally {
                translating = false
            }
        }
    }

    // ---------- Upload (photos, PDF, Word) ----------

    var importOpen by mutableStateOf(false)
        private set
    /** Progress text while files are being read or saved; null when idle. */
    var importBusy by mutableStateOf<String?>(null)
        private set
    /** Result / problems of the last read (shown on the upload screen). */
    var importMessage by mutableStateOf<String?>(null)
        private set
    var drafts by mutableStateOf<List<DraftQuestion>>(emptyList())
        private set
    /** Short message shown on the home screen after saving. */
    var notice by mutableStateOf<String?>(null)

    fun openImport() {
        importOpen = true
        importMessage = null
        drafts = emptyList()
    }

    fun closeImport() {
        if (importBusy != null) return
        importOpen = false
        importMessage = null
        drafts = emptyList()
    }

    fun clearDrafts() {
        if (importBusy != null) return
        drafts = emptyList()
        importMessage = null
    }

    /** Reads every chosen file, finds the questions and adds them to the preview list. */
    fun importFiles(uris: List<Uri>) {
        if (uris.isEmpty() || importBusy != null) return
        importBusy = "Starting…"
        importMessage = null
        viewModelScope.launch {
            val found = ArrayList<DraftQuestion>()
            val problems = ArrayList<String>()
            uris.forEachIndexed { i, uri ->
                val name = ImportEngine.displayName(getApplication(), uri)
                try {
                    val text = ImportEngine.extractText(getApplication(), uri) { step ->
                        importBusy = "File ${i + 1} of ${uris.size}: $name - $step"
                    }
                    val parsed = McqParser.parse(text)
                    if (parsed.isEmpty()) problems.add("$name: no questions found")
                    parsed.forEach { found.add(toDraft(it, name)) }
                } catch (e: Exception) {
                    problems.add("$name: ${e.message ?: "could not be read"}")
                }
            }
            // Same question text twice in one upload: keep the first
            val seen = HashSet<String>(drafts.map { QuestionRepository.normalize(it.text) })
            val fresh = found.filter { seen.add(QuestionRepository.normalize(it.text)) }
            val dupes = found.size - fresh.size
            drafts = drafts + fresh
            importMessage = buildString {
                append("Found ${fresh.size} questions")
                if (dupes > 0) append(" ($dupes repeated ones ignored)")
                problems.forEach { append("\n• ").append(it) }
            }
            importBusy = null
        }
    }

    private fun toDraft(p: ParsedQuestion, source: String): DraftQuestion {
        val category = p.category?.takeIf { it.isNotBlank() }
            ?: Categorizer.classify(p.text, p.options)
            ?: Categorizer.FALLBACK
        return DraftQuestion(
            text = p.text,
            options = p.options,
            answer = p.answer,
            category = category,
            source = source
        )
    }

    fun updateDraft(id: String, change: (DraftQuestion) -> DraftQuestion) {
        drafts = drafts.map { if (it.id == id) change(it) else it }
    }

    fun setCategoryForAll(name: String) {
        val n = name.trim()
        if (n.isEmpty()) return
        drafts = drafts.map { it.copy(category = n) }
    }

    /** Saves the ticked questions, grouped by category (new categories are created). */
    fun saveDrafts() {
        val chosen = drafts.filter { it.include }
        if (importBusy != null || chosen.isEmpty() || chosen.any { !it.isValid }) return
        importBusy = "Saving…"
        viewModelScope.launch {
            try {
                val app = getApplication<Application>()
                val summary = withContext(Dispatchers.IO) {
                    var added = 0
                    var skipped = 0
                    val created = ArrayList<String>()
                    val groups = chosen.groupBy { QuestionRepository.normalize(it.category) }
                    for ((_, list) in groups) {
                        val title = list.first().category.trim().ifEmpty { Categorizer.FALLBACK }
                        val result = UserStore.addQuestions(
                            app, title,
                            list.map { ImportedQuestion(it.text, it.options, it.answer ?: 0) }
                        )
                        added += result.added
                        skipped += result.skipped
                        if (result.createdCategory) created.add(title)
                    }
                    buildString {
                        append("Added $added questions")
                        if (skipped > 0) append(" ($skipped duplicates skipped)")
                        if (created.isNotEmpty()) append("\nNew categories: ${created.joinToString(", ")}")
                    }
                }
                refreshPapers()
                notice = summary
                importOpen = false
                drafts = emptyList()
                importMessage = null
            } catch (e: Exception) {
                importMessage = "Could not save: ${e.message ?: "unknown error"}"
            } finally {
                importBusy = null
            }
        }
    }
}
