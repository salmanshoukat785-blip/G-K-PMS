package com.ppsc.quiz.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ppsc.quiz.ShownQuestion

private val LETTERS = "ABCD"

@Composable
fun QuizScreen(
    paperTitle: String,
    question: ShownQuestion,
    position: Int,          // 1-based
    total: Int,
    selected: Int?,         // null = not answered yet
    onSelect: (Int) -> Unit,
    onNext: () -> Unit,
    onExit: () -> Unit,
    // online translation
    translateOn: Boolean,
    translating: Boolean,
    translateError: Boolean,
    translated: (String) -> String?,
    onToggleTranslate: () -> Unit,
    onRetryTranslate: () -> Unit
) {
    Column(Modifier.fillMaxSize().background(QuizColors.Page)) {

        // Top bar
        Row(
            Modifier.fillMaxWidth().background(QuizColors.Navy)
                .padding(horizontal = 8.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("‹", color = Color.White, fontSize = 30.sp,
                modifier = Modifier.clickable { onExit() }.padding(horizontal = 12.dp))
            Text(paperTitle, color = Color.White, fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold, maxLines = 1,
                modifier = Modifier.weight(1f))
            // Urdu translation switch
            Surface(
                color = if (translateOn) QuizColors.Gold else Color.Transparent,
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier
                    .border(1.dp, QuizColors.Gold, RoundedCornerShape(20.dp))
                    .clickable { onToggleTranslate() }
            ) {
                Text("اردو", fontWeight = FontWeight.Bold, fontSize = 14.sp,
                    color = if (translateOn) QuizColors.NavyDark else QuizColors.Gold,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 5.dp))
            }
            Text("$position / $total", color = QuizColors.Gold, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 12.dp))
        }
        LinearProgressIndicator(
            progress = { position.toFloat() / total },
            modifier = Modifier.fillMaxWidth(),
            color = QuizColors.Gold,
            trackColor = QuizColors.NavyDark
        )

        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Translation status
            if (translateOn && translating) {
                Text("Translating…", color = Color(0xFF5B5675), fontSize = 13.sp)
            }
            if (translateOn && translateError) {
                Text("Translation failed - check internet. Tap to retry.",
                    color = QuizColors.Red, fontSize = 13.sp,
                    modifier = Modifier.clickable { onRetryTranslate() })
            }

            // Question card
            Surface(color = QuizColors.Card, shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.Top) {
                    Box(
                        Modifier.size(34.dp).background(QuizColors.Navy, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("${question.number}", color = Color.White,
                            fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                    Column(Modifier.padding(start = 12.dp).weight(1f)) {
                        if (question.isNew) {
                            NewBadge("NEW • نیا")
                            Spacer(Modifier.height(6.dp))
                        }
                        Text(question.text, fontSize = 18.sp, fontWeight = FontWeight.SemiBold,
                            color = QuizColors.Ink)
                        if (translateOn) {
                            UrduText(translated(question.text), 18.sp, QuizColors.Navy,
                                Modifier.padding(top = 8.dp))
                        }
                    }
                }
            }

            // Options
            question.options.forEachIndexed { i, text ->
                OptionRow(
                    letter = LETTERS[i],
                    text = text,
                    urdu = if (translateOn) (translated(text) ?: "…") else null,
                    state = optionState(i, selected, question.correctIndex),
                    onClick = { onSelect(i) }
                )
            }

            // Answer bar (shown after the first tap)
            if (selected != null) {
                val right = selected == question.correctIndex
                Surface(
                    color = if (right) QuizColors.Green else QuizColors.Red,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(horizontal = 14.dp, vertical = 12.dp)) {
                        Text(
                            (if (right) "✓ " else "✗ ") +
                                "ANSWER ${question.correctLetter} — ${question.correctText}",
                            color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp
                        )
                        if (translateOn) {
                            UrduText(translated(question.correctText), 15.sp, Color.White,
                                Modifier.padding(top = 4.dp))
                        }
                    }
                }
            }
        }

        // Next button (only after answering)
        if (selected != null) {
            Button(
                onClick = onNext,
                colors = ButtonDefaults.buttonColors(containerColor = QuizColors.Navy),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().padding(16.dp)
            ) {
                Text(if (position == total) "Finish" else "Next", fontSize = 17.sp,
                    modifier = Modifier.padding(vertical = 4.dp))
            }
        }
    }
}

/** Urdu is right-to-left; "…" is shown while the translation is still loading. */
@Composable
private fun UrduText(text: String?, size: TextUnit, color: Color, modifier: Modifier = Modifier) {
    Text(
        text ?: "…",
        fontSize = size,
        color = color,
        textAlign = TextAlign.Start,
        style = TextStyle(textDirection = TextDirection.Rtl),
        modifier = modifier.fillMaxWidth()
    )
}

private enum class OptionState { Neutral, Correct, Wrong }

/** Correct option turns green once answered; the tapped wrong option turns red. */
private fun optionState(index: Int, selected: Int?, correct: Int): OptionState = when {
    selected == null -> OptionState.Neutral
    index == correct -> OptionState.Correct
    index == selected -> OptionState.Wrong
    else -> OptionState.Neutral
}

@Composable
private fun OptionRow(
    letter: Char,
    text: String,
    urdu: String?,          // null = translation is off
    state: OptionState,
    onClick: () -> Unit
) {
    val bg = when (state) {
        OptionState.Correct -> QuizColors.GreenLight
        OptionState.Wrong -> QuizColors.RedLight
        OptionState.Neutral -> Color.White
    }
    val accent = when (state) {
        OptionState.Correct -> QuizColors.Green
        OptionState.Wrong -> QuizColors.Red
        OptionState.Neutral -> QuizColors.Navy
    }
    Row(
        Modifier
            .fillMaxWidth()
            .background(bg, RoundedCornerShape(12.dp))
            .border(
                width = if (state == OptionState.Neutral) 1.dp else 2.dp,
                color = if (state == OptionState.Neutral) Color(0xFFD8D3F0) else accent,
                shape = RoundedCornerShape(12.dp)
            )
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(30.dp).background(
                if (state == OptionState.Neutral) QuizColors.Card else accent, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text("$letter", fontWeight = FontWeight.Bold, fontSize = 13.sp,
                color = if (state == OptionState.Neutral) QuizColors.Navy else Color.White)
        }
        Column(Modifier.padding(start = 12.dp).weight(1f)) {
            Text(text, fontSize = 16.sp, color = QuizColors.Ink,
                fontWeight = if (state == OptionState.Neutral) FontWeight.Normal else FontWeight.SemiBold)
            if (urdu != null) {
                UrduText(urdu, 15.sp, Color(0xFF3B3566), Modifier.padding(top = 4.dp))
            }
        }
    }
}
